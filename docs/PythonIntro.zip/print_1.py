# -*- coding: utf-8 -*-
"""
Created on Thu Jun 28 10:29:50 2018

@author: u0015831
"""

print('Hello')

a = 5
b = 7
# multiple objects
print('a =', a, ' b', b)
# use separator
l = [10, 1, 33, 34]
print(*l, sep='.')
print(*l, sep='\n')
