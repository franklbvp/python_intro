# -*- coding: utf-8 -*-
"""
Created on Mon Nov 18 20:54:12 2019

@author: u0015831
"""

def print_greet( par ):
   print('Greetings My Dear ', par)
   return

if __name__ == '__main__' :   # test the code without if
   print_greet('all_of_you')