# -*- coding: utf-8 -*-
"""
Created on Fri May 31 14:00:55 2019

@author: u0015831
"""

print("Hi, this is a Python program")
