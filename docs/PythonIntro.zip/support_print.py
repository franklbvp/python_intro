# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 12:11:46 2019

module containing different functions that can be used to print

@author: u0015831
"""


def print_func( name ):
   print("Hello : ", name)
   return

def print_func_fancy( name ):
   print("Hello My Dear: ", name)
   return