# -*- coding: utf-8 -*-
"""
Created on Mon Jan  7 16:12:28 2019

source: https://swcarpentry.github.io/python-novice-inflammation/03-lists/index.html
@author: u0015831
"""

my_list = []
for char in "hello":
    my_list.append(char)
print(my_list)