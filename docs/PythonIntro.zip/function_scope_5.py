# -*- coding: utf-8 -*-
"""
Created on Sun Nov 15 09:25:39 2020

@author: https://www.tutorialsteacher.com/python/local-and-global-variables-in-python
"""

def SayHello():
    user='John'
    print ("user = ", user)
    return

def SayHello_wrong():
    print ("user = ", user)
    return

def SayHello_global():
    global user
    print ("user = ", user)
    user = 'Mary'
    return


user = 'Jeff'
SayHello_wrong()

user = 'Jeff'
print('user', user)
SayHello()


print('user', user)
SayHello_global()
print('user', user)

