# -*- coding: utf-8 -*-
"""
Created on Mon Nov 18 20:56:06 2019

@author: u0015831
"""

from print_greet_main import print_greet

name1 = 'Jan'
print_greet(name1)