# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 10:06:04 2019

getting help
- dir
- help

@author: u0015831
"""

a = "string"
dir(a)

help(a.split)
