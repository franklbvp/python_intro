# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 09:26:53 2019

My first script
- create some variables
- make some calculations
@author: u0015831
"""
a = 1
b = 8.7

c = a + b
print('c = ', c)

d = a / b
print('d = ', d)
