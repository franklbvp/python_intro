# -*- coding: utf-8 -*-
"""
Created on Thu Jul  5 14:00:38 2018

@author: u0015831
"""

import math
print(math.cos(math.pi))

import numpy as np
print(np.cos(np.pi))