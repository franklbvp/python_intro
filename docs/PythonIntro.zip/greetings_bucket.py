# -*- coding: utf-8 -*-
"""
Created on Fri Nov 13 16:17:00 2020

@author: u0015831
"""

def greetings(name):
    """This function greets the name passed as an argument"""
    print('Hello, ', name , '  Welcome!')
    