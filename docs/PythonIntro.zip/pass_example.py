# -*- coding: utf-8 -*-
"""
Created on Sat Nov 11 19:20:37 2023

@author: u0015831
"""

n = 11

# use pass inside if statement
if n > 10:
    # TODO complete this code!
    # test to comment pass
    pass
print('Hello')