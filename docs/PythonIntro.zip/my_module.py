# my_module.py
"""
Created on Thu Jun 28 16:33:19 2018

@author: u0015831
"""

"""This is a simple module.
It shows how modules work"""
x = 1+2
x = 3*x

print(x)