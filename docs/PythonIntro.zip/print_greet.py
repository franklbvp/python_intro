# -*- coding: utf-8 -*-
"""
Created on Mon Nov 18 20:54:12 2019

@author: u0015831
"""

def print_greet( par ):
   print('Greetings My Dear ', par)
   return

# test the function
print_greet('all_of_you')