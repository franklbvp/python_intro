# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 12:12:03 2019

 calculate sum of 1 up to 100

 do it with a while loop

@author: u0015831
"""

sum100 = 0
i = 1

while i <= 100 : 
    sum100 = sum100 + i
    i = i + 1

print('sum100 = ', sum100)    