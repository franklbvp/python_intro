# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 10:23:48 2019


 calculate sum of 1 up to 100

 do it the 'brute force' way

@author: u0015831
"""


sum100 = 0 

sum100 = sum100 + 1 
sum100 = sum100 + 2 
sum100 = sum100 + 3 
sum100 = sum100 + 4 
sum100 = sum100 + 5 
sum100 = sum100 + 6 
sum100 = sum100 + 7 
sum100 = sum100 + 8 
sum100 = sum100 + 9 

sum100 = sum100 + 10 
sum100 = sum100 + 11 
sum100 = sum100 + 12 
sum100 = sum100 + 13 
sum100 = sum100 + 14 
sum100 = sum100 + 15 
sum100 = sum100 + 16 
sum100 = sum100 + 17 
sum100 = sum100 + 18 
sum100 = sum100 + 19 

sum100 = sum100 + 20 
sum100 = sum100 + 21 
sum100 = sum100 + 22 
sum100 = sum100 + 23 
sum100 = sum100 + 24 
sum100 = sum100 + 25 
sum100 = sum100 + 26 
sum100 = sum100 + 27 
sum100 = sum100 + 28 
sum100 = sum100 + 29 

sum100 = sum100 + 30 
sum100 = sum100 + 31 
sum100 = sum100 + 32 
sum100 = sum100 + 33 
sum100 = sum100 + 34 
sum100 = sum100 + 35 
sum100 = sum100 + 36 
sum100 = sum100 + 37 
sum100 = sum100 + 38 
sum100 = sum100 + 39 

sum100 = sum100 + 40 
sum100 = sum100 + 41 
sum100 = sum100 + 42 
sum100 = sum100 + 43 
sum100 = sum100 + 44 
sum100 = sum100 + 45 
sum100 = sum100 + 46 
sum100 = sum100 + 47 
sum100 = sum100 + 48 
sum100 = sum100 + 49 

sum100 = sum100 + 50 
sum100 = sum100 + 51 
sum100 = sum100 + 52 
sum100 = sum100 + 53 
sum100 = sum100 + 54 
sum100 = sum100 + 55 
sum100 = sum100 + 56 
sum100 = sum100 + 57 
sum100 = sum100 + 58 
sum100 = sum100 + 59 

sum100 = sum100 + 60 
sum100 = sum100 + 61 
sum100 = sum100 + 62 
sum100 = sum100 + 63 
sum100 = sum100 + 64 
sum100 = sum100 + 65 
sum100 = sum100 + 66 
sum100 = sum100 + 67 
sum100 = sum100 + 68 
sum100 = sum100 + 69 

sum100 = sum100 + 70 
sum100 = sum100 + 71 
sum100 = sum100 + 72 
sum100 = sum100 + 73 
sum100 = sum100 + 74 
sum100 = sum100 + 75 
sum100 = sum100 + 76 
sum100 = sum100 + 77 
sum100 = sum100 + 78 
sum100 = sum100 + 79 

sum100 = sum100 + 80 
sum100 = sum100 + 81 
sum100 = sum100 + 82 
sum100 = sum100 + 83 
sum100 = sum100 + 84 
sum100 = sum100 + 85 
sum100 = sum100 + 86 
sum100 = sum100 + 87 
sum100 = sum100 + 88 
sum100 = sum100 + 89 

sum100 = sum100 + 90 
sum100 = sum100 + 91 
sum100 = sum100 + 92 
sum100 = sum100 + 93 
sum100 = sum100 + 94 
sum100 = sum100 + 95 
sum100 = sum100 + 96 
sum100 = sum100 + 97 
sum100 = sum100 + 98 
sum100 = sum100 + 99 

sum100 = sum100 + 100 

print('sum100 = ', sum100)
