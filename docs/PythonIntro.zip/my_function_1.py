# -*- coding: utf-8 -*-
"""
Created on Wed Jun 27 10:17:12 2018

can I use this file? a la Matlab function?

@author: u0015831
"""

def my_function_1():
    """ this function is printing a message
    this function has no passing parameters
    is not returning anything
    """
    print('I am my_function_1')
    