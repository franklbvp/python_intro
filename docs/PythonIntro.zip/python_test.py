print("Running test.py")
a = 1
b = 2.3
c = a / b
print(c)