print("Running test.py")
x = 5
print("Result is", 3 * x)