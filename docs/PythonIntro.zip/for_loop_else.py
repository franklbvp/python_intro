# -*- coding: utf-8 -*-
"""
Created on Sun Nov 12 13:57:24 2023

@author: u0015831
"""

numbers =[1,2,3,4]
for i in numbers: 
    print(i) 
    if i > 2:  # try with 8
       break
else: # Not executed as there is a break 
    print("No Break") 
