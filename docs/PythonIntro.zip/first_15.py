a = 1
b = 3.3
c = a + b
print(c, a, b)