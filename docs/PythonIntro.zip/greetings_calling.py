# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 10:12:42 2019

basic usage of a function

@author: u0015831
"""

from greetings import greetings

# use the function multiple times
greetings('Jan')
greetings('Lieve')
greetings('Jef')

