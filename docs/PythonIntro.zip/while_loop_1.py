# -*- coding: utf-8 -*-
"""
Created on Wed Jun 20 16:48:54 2018

basic while loop

@author: u0015831
"""

count = 1
while (count <= 10):
   print("The count is:", count)
count = count + 1

print("while loop has ended")