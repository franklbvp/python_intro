# -*- coding: utf-8 -*-
"""
Created on Fri Feb 19 08:07:33 2021

@author: u0015831
"""

from print_greet_main import print_greet

print_greet('jan')
print_greet('jules')
