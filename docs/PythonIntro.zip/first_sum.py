# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 09:48:16 2019

@author: u0015831
"""

a = 1
b = 7
c = a + b
print(a+b)

if (a > 6):
    print('a larger than 6')

