m# -*- coding: utf-8 -*-
"""
Created on Mon Nov 25 17:02:29 2019

@author: u0015831
"""


def hello():
    """Print "Hello World" """
    print("Later World")

# Main program starts here
# once executed, the function hello is known
# the function can be called at the console
hello()
