# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 12:02:55 2019

 calculate sum of 1 up to 100

 do it with a for loop

@author: u0015831
"""
sum100 = 0

for i in range(1,101):
    sum100 = sum100 + i

print('sum100 = ', sum100)    