# -*- coding: utf-8 -*-
"""
Created on Thu Jun  6 14:47:11 2019

@author: http://ice-web.cc.gatech.edu/ce21/1/static/audio/static/pip/Iteration/iteration.html
"""

nums = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
accum = 0
for w in nums:
   accum = accum + w
   print(accum)

