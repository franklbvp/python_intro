#!/usr/bin/env python

# =============================================================================
# print('hello world')
# print('hello world')
# print('hello world')
# =============================================================================

#%% 
print('hello world') # more
print('hello class') # text

#%%
print('hello world') # more
print('hello class') # text
