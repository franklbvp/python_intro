# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 09:59:38 2020

@author: u0015831
"""

a = 1
b = 2.2
c = a + b
print(c)