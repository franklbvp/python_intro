# -*- coding: utf-8 -*-
"""
Created on Wed Jun 13 10:43:56 2018

@author: u0015831
"""

x = 5
y = 7
z = x + y