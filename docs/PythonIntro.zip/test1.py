

a = 8
b = 8.8
c = a + b
print(c)