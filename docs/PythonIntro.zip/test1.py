# -*- coding: utf-8 -*-
"""
Created on Fri Feb 21 09:58:50 2020

@author: u0015831
"""

a = 8
b = 8.8
c = a + b
print(c)