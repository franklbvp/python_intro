a = 1.1
b = 2.33
c = a + b
print(c)