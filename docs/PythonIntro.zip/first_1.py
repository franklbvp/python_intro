# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

a = 1
b = 2.2
c = a + b
print(c)