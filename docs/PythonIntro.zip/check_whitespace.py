# -*- coding: utf-8 -*-
"""
Created on Thu Jun 14 10:34:11 2018
check the White Space!
@author: u0015831
"""
#%%
for i in range(3):
    print("Hello")
    print("Bye!")

#%%
for i in range(10):
    if i%2 == 1:
        print (0.1*i)
        print ('bla')
print('end block')

#%%
for i in range(10):
    if i%2 == 1:
        print (0.1*i)
print ('bla')
print('end block')

#%%
for i in range(10):
    if i%2 == 1:
        print (0.1*i)
    print('bla')
print('end block')