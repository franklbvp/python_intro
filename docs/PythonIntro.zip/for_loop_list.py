# -*- coding: utf-8 -*-
"""
Created on Wed Jun 20 14:20:38 2018

@author: u0015831
"""

#my_list = [1, 2, 32]
my_list = (1, 2, 3)

for i in my_list:
    print(my_list[i])