# -*- coding: utf-8 -*-
"""
Created on Wed Nov 18 09:52:08 2020

@author: u0015831
"""

a = 1
b = 1.2

c = a + b
print(c)