# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 12:15:05 2019

@author: u0015831
"""

import support_print

support_print.print_func('Jules')

support_print.print_func_fancy('Tom')