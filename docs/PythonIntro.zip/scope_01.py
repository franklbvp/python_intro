# -*- coding: utf-8 -*-
"""
Created on Sun Nov 12 17:10:52 2023

@author: u0015831
"""

j = 1
while(j <= 5):
    print(j)
    j = j + 1
    k = j

print('j =', j)
print('k =', k)
