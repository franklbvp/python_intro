#!/usr/bin/env python

print('hello world')

input('Press Enter to Continue...')