# -*- coding: utf-8 -*-
"""
Created on Wed Jun 27 10:36:03 2018

@author: u0015831
"""

def my_func_1 ():
    """
    this function writes hello
    """
    print('Hello')
    
def my_func_2(a, b):
    """
    parameters:
        a: first part of mathematical manip
        b: second part in mathematical manip
    """
    res = a + b
    return (res)

def my_func_3(a, b):
    """
    parameters:
        a: first part of mathematical manip
        b: second part in mathematical manip
    """
    res1 = a + b
    res2 = a - b
    return (res1, res2)

# main part, calling the functions
my_func_1()
    
my_func_2(5,6) # effect?
a = my_func_2(5,6)
print(type(a))
print(a)

b = my_func_3(5,6)
print(type(b))
print(b)