# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 10:12:42 2019

basic usage of a function

@author: u0015831
"""

def greetings(name):
    """This function greets the name passed as an argument"""
    print('Hello, ', name , '  Welcome!')
    

# use the function multiple times
greetings('Jan')
greetings('Lieve')
greetings('Jef')

