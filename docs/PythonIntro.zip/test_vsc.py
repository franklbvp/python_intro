# function import 2 variables, calculate sum and product
x = 'string'
print(x)
print(type(x))
y = x.capitalize()
print(y)