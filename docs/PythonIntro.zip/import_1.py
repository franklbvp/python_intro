# -*- coding: utf-8 -*-
"""
Created on Mon Nov 18 20:48:23 2019

@author: u0015831
"""

import math 
print(math.pi) 