# -*- coding: utf-8 -*-
"""
Created on Sat Nov 12 14:25:31 2022

@author: u0015831
"""

x = lambda a : a + 10
f = lambda a, b: a + b 

print(x(6))
print(f(5.6,6))