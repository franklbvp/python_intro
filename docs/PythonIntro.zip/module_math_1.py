# -*- coding: utf-8 -*-
"""
Created on Thu Jun 28 16:20:24 2018

@author: u0015831
"""

import math
print(math.cos(90.0))
print(math.pi)
print(math.cos(math.pi))