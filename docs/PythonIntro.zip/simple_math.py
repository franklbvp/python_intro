# -*- coding: utf-8 -*-
"""
Created on Fri Jun 29 14:23:12 2018
source: http://www.cs.cornell.edu/courses/cs1110/2018sp/
@author: u0015831
"""

# simple_math.py
"""module with two simple
math functions"""
def increment(n):
    """Returns: n+1"""
    return n+1

def decrement(n):
    """Returns: the value of n-1"""
    return n-1
