# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 12:15:05 2019

demo 1: try to run without import

demo 2: run the code in debug mode

@author: u0015831
"""

from support_print import print_func
from support_print import print_func_fancy

# no need to specify the module
print_func('Jules')

print_func_fancy('Tom')