# -*- coding: utf-8 -*-
"""
Created on Tue Nov 15 10:00:23 2022

@author: u0015831
"""

a = 3
b = 8
c = a + b
