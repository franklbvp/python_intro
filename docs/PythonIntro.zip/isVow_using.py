# -*- coding: utf-8 -*-
"""
Created on Sat Nov 12 14:43:11 2022

@author: u0015831
"""

import isVow_script
import isVow_module


# call isVow the bad way
print('regular file')
print(isVow_script.isVow('i'))
print(isVow_script.isVow('y'))


# call isVow the right way
print('name == main')
print(isVow_module.isVow('i'))
print(isVow_module.isVow('y'))