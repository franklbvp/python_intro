# -*- coding: utf-8 -*-
"""
Created on Fri Nov 29 12:15:05 2019

demo 1: try to run without import

demo 2: run the code in debug mode

@author: u0015831
"""

import support_print

support_print.print_func('Jules')

support_print.print_func_fancy('Tom')