a = 1 
b = 4.5
c = a + b
print(a, b, c)